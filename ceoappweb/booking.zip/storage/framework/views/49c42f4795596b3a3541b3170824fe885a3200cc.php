

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title">Profile</h4>
                                <p class="card-category">Datos de Pefil</p>
                            </div>
                            <div class="card-body">
                                <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                                <?php elseif(session('danger')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('danger')); ?>

                                </div>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="card">
                                        <div class="card-header card-header-primary">
                                            <h4 class="card-title">Cambiar Contraseña</h4>
                                            <p class="card-category">Ingresar los datos</p>
                                        </div>
                                        <form action="<?php echo e(route('profile.update')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>

                                        <div class="card-body ">
                                            <div class="row">
                                                
                                                
                                                <label class="col-sm-2 col-form-label" for="input-current-password">Contraseña Actual</label>
                                                <div class="col-sm-7">
                                                    <div class="form-group bmd-form-group">
                                                    <input class="form-control" input="" type="password" name="old_password" id="input-current-password" placeholder="Contraseña Actual" value="" required="">
                                                                        </div>
                                                </div>
                                                </div>
                                                <div class="row">
                                                <label class="col-sm-2 col-form-label" for="input-password">Nueva Contraseña</label>
                                                <div class="col-sm-7">
                                                    <div class="form-group bmd-form-group">
                                                    <input class="form-control" name="password" id="input-password" type="password" placeholder="Nueva Contraseña" value="" required="">
                                                                        </div>
                                                </div>
                                                </div>
                                                <div class="row">
                                                <label class="col-sm-2 col-form-label" for="input-password-confirmation">Confirmar Contraseña</label>
                                                <div class="col-sm-7">
                                                    <div class="form-group bmd-form-group">
                                                    <input class="form-control" name="password_confirmation" id="input-password-confirmation" type="password" placeholder="Confirmar Contraseña" value="" required="">
                                                    </div>
                                                </div>
                                                
                                                
                                                </div>
                                                <br>
                                                <button type="submit" class="btn btn-success ">Actualizar</button>
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card card-user">
                                            <div class="card-body">
                                                <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p class="card-text">
                                                    <div class="auth">
                                                        <a href="#">
                                                            <div style="padding:10px">
                                                                <img src="http://oca.soporbapp.cl/archivos/<?php echo e($profile->img); ?>" alt=""  class="avatar img-circle img-thumbnail" style="width: 75%;margin-left: 30px;height: 200px;">
                                                            </div>
                                                            <h5 class="title mt-3">
                                                                <span style="font-weight: bold">Nombre:</span> <?php echo e($profile->name.' '.$profile->lastname); ?> 
                                                            </h5>
                                                        </a>
                                                        <p class="description">
                                                        <span style="font-weight: bold">Email:</span> <?php echo e($profile->email); ?> <br>
                                                        <span style="font-weight: bold"> Direccion:</span> <?php echo e($profile->address); ?> <br>
                                                        <span style="font-weight: bold">Fecha de nacimiento: </span><?php echo e($profile->date_born); ?> <br>
                                                        <span style="font-weight: bold">Telefono: </span> +56 <?php echo e($profile->phone); ?>

                                                        </p>
                                                    </div>
                                                </p>
                                                <div class="card-description"></div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer mr-auto">
                               
                            </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'profile', 'titlePage' => 'Profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\booking\resources\views/profile/index.blade.php ENDPATH**/ ?>