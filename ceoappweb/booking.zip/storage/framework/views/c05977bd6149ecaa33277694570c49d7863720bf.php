

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title">Mantenciones</h4>
                                <p class="card-category">Ultimas Mantenciones Agregadas</p>
                            </div>
                            <div class="card-body">
                                <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class="text-primary">
                                            
                                            <th>Patente</th>
                                            <th>Modelo V</th>
                                            <th>Fecha de Solicitud</th>
                                            <th>N° reserva</th>
                                            <th>Taller</th>
                                            <th>Fecha</th>
                                            <th>Hora</th>
                                            <th>Estatus</th>
                                            <th>Realizar <br> Mantencion</th>
                                            <th class="text-right"></th>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $mentenciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mantencion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($mantencion->patente); ?></td>
                                                <td><?php echo e($mantencion->modelo_v); ?></td>
                                                <td><?php echo e($mantencion->fecha_solicitud); ?></td>
                                                <td><?php echo e($mantencion->n_reserva); ?></td>
                                                <td><?php echo e(strtoupper($mantencion->taller)); ?></td>
                                                <td><?php echo e($mantencion->fecha); ?></td>
                                                <td><?php echo e($mantencion->hora); ?></td>
                                                <td class="td-actions">
                                                <?php if($mantencion->status == 'no realizado'): ?>
                                                <button type="submit" class="btn btn-danger">
                                                    <i class="material-icons">close</i>
                                                </button>
                                                <?php else: ?>
                                                <button type="submit" class="btn btn-success">
                                                    <i class="material-icons">check_circle</i>
                                                </button>
                                                <?php endif; ?>
                                                
                                                </td>
                                                <td class="td-actions"><a href="<?php echo e(route('mantencion.edit', $mantencion->id)); ?>" class="btn btn-primary"><i class="material-icons">car_repair</i></a></td>

                                                <td class="td-actions text-right">

                                                    
                                                <form action="route('mantencion.delete',$mantencion->id)" method="post" style="display:inline-block">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Desea Eliminar ')">
                                                            <i class="material-icons">restore_from_trash</i>
                                                    </button>
                                                 </form>
                                                 </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-footer mr-auto">
                               
                            </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'mantenciones', 'titlePage' => 'Mantenciones'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\booking\resources\views/mantencion/index.blade.php ENDPATH**/ ?>