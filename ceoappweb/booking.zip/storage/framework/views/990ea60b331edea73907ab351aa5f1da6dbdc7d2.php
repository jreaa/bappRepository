

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title">Examenes</h4>
                                <p class="card-category">Ultimos Examenes Agregados</p>
                            </div>
                            <div class="card-body">
                                <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class="text-primary">
                                            <th>Titulo</th>
                                            <th>Descripcion</th>
                                            <th>Link</th>
                                            <th>Estatus</th>
                                            <th class="text-right"></th>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($test->title); ?></td>
                                                <td><?php echo e($test->description); ?></td>
                                                <td><a href="<?php echo e($test->link); ?>"><?php echo e($test->link); ?></a></td>
                                                <td><?php echo e(strtoupper($test->status)); ?></td>
                                                <td class="td-actions text-right">

                                                    
                                                <form action="#" method="post" style="display:inline-block">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Desea Eliminar ')">
                                                            <i class="material-icons">restore_from_trash</i>
                                                    </button>
                                                 </form>
                                                 </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-footer mr-auto">
                               
                            </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'test', 'titlePage' => 'Examenes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\booking\resources\views/tests/index.blade.php ENDPATH**/ ?>