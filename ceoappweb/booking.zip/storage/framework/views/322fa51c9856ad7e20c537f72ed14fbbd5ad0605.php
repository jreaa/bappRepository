<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-stats">
            <div class="card-header card-header-danger card-header-icon">
              <div class="card-icon">
               <a href="<?php echo e(route('notificacion')); ?>" style="color:#fff"><i class="material-icons">circle_notifications</i></a> 
              </div>
              <p class="card-category">Notificaciones</p>
              <h3 class="card-title"><?php echo e(sizeof($notificaciones)); ?>

              </h3>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-stats">
            <div class="card-header card-header-info card-header-icon">
              <div class="card-icon">
                <a href="<?php echo e(route('test')); ?>" style="color:#fff"><i class="material-icons">edit</i></a>
              </div>
              <p class="card-category">Examenes</p>
              <h3 class="card-title"><?php echo e(sizeof($tests)); ?></h3>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-stats">
            <div class="card-header card-header-warning card-header-icon">
              <div class="card-icon">
                <a href="<?php echo e(route('mantencion')); ?>" style="color:#fff"><i class="material-icons">car_repair</i></a>
              </div>
              <p class="card-category">Mantenimientos</p>
              <h3 class="card-title"><?php echo e(sizeof($mentenciones)); ?></h3>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
              <div class="card-icon">
              <i class="material-icons">message</i>
              </div>
              <p class="card-category">Mensajes</p>
              <h3 class="card-title">+245</h3>
            </div>
          </div>
        </div>

        
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['notificaciones' => $notificaciones, 'activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\booking\resources\views/home.blade.php ENDPATH**/ ?>