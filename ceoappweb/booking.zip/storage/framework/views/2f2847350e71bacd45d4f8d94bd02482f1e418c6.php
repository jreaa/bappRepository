

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title">Control Temperatura</h4>
                                <p class="card-category">Temperatura</p>
                            </div>
                            <div class="card-body">
                                <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class="text-primary">
                                            <th>Fecha</th>
                                            <th>Jornada</th>
                                            <th>Hora</th>
                                            <th>Estatus</th>
                                            <th>Temperatura</th>
                                            <th class="text-right"></th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><?php echo e($control->date); ?></td>
                                                <td><?php echo e(strtoupper($control->jornada)); ?></td>
                                                <td><?php echo e($control->hora); ?></td>
                                                <td><?php echo e(strtoupper($control->status)); ?></td>

                                                <form action="<?php echo e(route('control_temp.update', $control->id)); ?>" method="post" style="display:inline-block">
                                                <td class="td-actions ">
                                                    <input type="number" name="temperatura" class="form-control" step="0.01" required>
                                                </td>

                                                <td class="td-actions text-right">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <button type="submit" class="btn btn-success" onclick="return confirm('Esta seguro que desea guardar? ')">
                                                        Guardar
                                                    </button>
                                                
                                                </td>
                                                </form>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-footer mr-auto">
                               
                            </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'controlTemp', 'titlePage' => 'Control Temperatura'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\booking\resources\views/controlTemperatura/edit.blade.php ENDPATH**/ ?>