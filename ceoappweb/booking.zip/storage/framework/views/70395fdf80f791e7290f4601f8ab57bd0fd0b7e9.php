<div class="sidebar" data-color="orange" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="https://creative-tim.com/" class="simple-text logo-normal">
      <img src="<?php echo e(asset('img/bapp.png')); ?>" alt="Logo Bapp" style="width:80%;height:60px">
    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Panel de Control')); ?></p>
        </a>
      </li>
      <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" data-toggle="collapse" href="#laravelExample" aria-expanded="true">
          <i><img style="width:25px" src="<?php echo e(asset('img/laravel.svg')); ?>"></i>
          <p><?php echo e(__('Protocolos')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse show" id="laravelExample">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'controlTemp' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('control_temp')); ?>">
                <span class="sidebar-mini"> CT </span>
                <span class="sidebar-normal"><?php echo e(__('Control Temperatura')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'sanitizacion' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('sanitizacion')); ?>">
                <span class="sidebar-mini"> SN </span>
                <span class="sidebar-normal"> <?php echo e(__('Sanitizacion ')); ?> </span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item<?php echo e($activePage == 'test' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('test')); ?>">
          <i class="material-icons">edit</i>
            <p><?php echo e(__('Examenes')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'notificacion' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('notificacion')); ?>">
          <i class="material-icons">circle_notifications</i>
            <p><?php echo e(__('Notificaciones')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'mantenciones' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('mantencion')); ?>">
          <i class="material-icons">car_repair</i>
            <p><?php echo e(__('Mantenimiento')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'documentaria' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('documentaria')); ?>">
          <i class="material-icons">file_present</i>
            <p><?php echo e(__('Documentaria')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'typography' ? ' active' : ''); ?>">
        <a class="nav-link" href="#">
          <i class="material-icons">message</i>
            <p><?php echo e(__('Mensajes')); ?></p>
        </a>
      </li>
    </ul>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\booking\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>