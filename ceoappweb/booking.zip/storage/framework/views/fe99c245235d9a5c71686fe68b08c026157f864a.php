<footer class="footer">
    <div class="container">
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>,
        <a href="https://www.creative-tim.com" target="_blank">Bapp</a> todos los derechos reservados.
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\booking\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>